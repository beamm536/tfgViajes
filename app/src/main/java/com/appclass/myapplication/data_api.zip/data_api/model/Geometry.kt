package com.appclass.myapplication.data_api.model


//modelo de datos para las coordenadas
data class Geometry(
    val coordinates: List<Double>
)
